package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer")
public class Customer {

	@Id;
	private long cusid;
	private String cusname;
	private String city;
	private int mobilenumber;
	private String email;

	
	
	
	public Customer() {
		super();
	}

	public Customer(String cusname, String city, int mobilenumber, String email) {
		super();
		this.cusname = cusname;
		this.city = city;
		this.mobilenumber = mobilenumber;
		this.email = email;
	}

	public long getCusid() {
		return cusid;
	}

	public void setCusid(long cusid) {
		this.cusid = cusid;
	}

	public String getCusname() {
		return cusname;
	}

	public void setCusname(String cusname) {
		this.cusname = cusname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(int mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
