package com.example.demo.repositories;

import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Customer;

@Repository
public interface CustomerRepository extends MongoRepository<Customer, Long>{

	
	
}
