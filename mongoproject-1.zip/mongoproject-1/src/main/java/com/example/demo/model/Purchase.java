package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "purchase")
public class Purchase {

	@Id
	private long purchaseorderid;
	private long cusid;
	private int Quantitiy;
	private String productname;
	private double price;
	private double MRP;
	
	
	public Purchase() {
		super();
	}


	public Purchase(long cusid, int quantitiy, String productname, double price, double mRP) {
		super();
		this.cusid = cusid;
		Quantitiy = quantitiy;
		this.productname = productname;
		this.price = price;
		MRP = mRP;
	}


	public long getPurchaseorderid() {
		return purchaseorderid;
	}


	public void setPurchaseorderid(long purchaseorderid) {
		this.purchaseorderid = purchaseorderid;
	}


	public long getCusid() {
		return cusid;
	}


	public void setCusid(long cusid) {
		this.cusid = cusid;
	}


	public int getQuantitiy() {
		return Quantitiy;
	}


	public void setQuantitiy(int quantitiy) {
		Quantitiy = quantitiy;
	}


	public String getProductname() {
		return productname;
	}


	public void setProductname(String productname) {
		this.productname = productname;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public double getMRP() {
		return MRP;
	}


	public void setMRP(double mRP) {
		MRP = mRP;
	}
		
}
