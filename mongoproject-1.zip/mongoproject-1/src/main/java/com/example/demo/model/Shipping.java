package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "shipping")
public class Shipping {

	@Id
	private String address;
	private String city;
	private int pincode;
	private long purchaseorderid;
	private long cusid;
	
	
	public Shipping() {
		super();
	}

	public Shipping(String address, String city, int pincode, long purchaseorderid, long cusid) {
		super();
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.purchaseorderid = purchaseorderid;
		this.cusid = cusid;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public int getPincode() {
		return pincode;
	}



	public void setPincode(int pincode) {
		this.pincode = pincode;
	}



	public long getPurchaseorderid() {
		return purchaseorderid;
	}



	public void setPurchaseorderid(long purchaseorderid) {
		this.purchaseorderid = purchaseorderid;
	}



	public long getCusid() {
		return cusid;
	}



	public void setCusid(long cusid) {
		this.cusid = cusid;
	}
	
	
	
	
	
}
